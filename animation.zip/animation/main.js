import gsap from 'gsap'
import { Timeline } from 'gsap/gsap-core'
import $ from 'jquery'


gsap.defaults({duration: 0.2})
let tl = gsap.timeline()

$('.btn').click(function() {
  tl
  .to('.btn', {
    backgroundImage: 'url(./public/btn2.png)',
    duration: 0
  })
  .to('.btn', {
    boxShadow: '0 0 0 30px #91793A4D',
  })
  .to('.line', {
    border: '3px solid #91793A',
    width: '75vw',
    height: '75vw',
  })
  .to('.menus', {
    display: 'flex',
    duration: 0
  })
  .to('.line', {
    rotate: 0,
  })
  
})



